<?php include"assest/common/doctype.php" ?>
<?php include"assest/common/all-links.php" ?>
</head>
<body>
   
<!--
   <div id="preloader">
  <div id="status">&nbsp;</div>
</div>
-->
   
    <div class="col-lg-6 login">
        <div class="login-header">
            <h1>Administrator Login</h1>
        </div>
        <div class="login-form">
            <div class="wrap">
                <div class="mat-div">
                    <label for="first-name" class="mat-label">User Name</label>
                    <input type="text" class="mat-input" id="user-name">
                </div>
                <div class="mat-div">
                    <label for="first-name" class="mat-label">Password</label>
                    <input type="text" class="mat-input" id="Password">
                </div>
                
               
                <div class="form-group">
                    <a class="sign-up">Login</a>
                </div>

            </div>
        </div>
    </div>
<script src="assest/js/common.js"></script>
</body>
</html>
