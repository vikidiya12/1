<?php include"assest/common/doctype.php" ?>
<?php include"assest/common/all-links.php" ?>
</head>

<body>


    <!--
   <div id="preloader">
  <div id="status">&nbsp;</div>
</div>
-->

    <div class="col-lg-6 login">
        <div class="login-header">
            <h1>Student Registration</h1>
        </div>
        <div class="login-form">
            <div class="wrap">
                <div class="mat-div">
                    <label for="first-name" class="mat-label">Name *</label>
                    <input type="text" class="mat-input" id="user-name">
                </div>

                <div class="mat-div">
                    <label for="first-name" class="mat-label">Register No *</label>
                    <input type="text" class="mat-input" id="registerno">
                </div>
                   
                <div class="mat-div">
                    <label for="first-name" class="mat-label">Date Of Birth *</label>
                    <input type="text" class="mat-input" id="dob">
                </div>
                 <div class="mat-div">
                    <label for="first-name" class="mat-label">Mobile No *</label>
                    <input type="text" class="mat-input" id="mobileno">
                </div>
                <div class="mat-div">
                    <label for="first-name" class="mat-label">Email Id *</label>
                    <input type="text" class="mat-input" id="emailid">
                </div>
<!--
                <div class="col-lg-12 check-st">
                    <div class="md-checkbox">
                        <input id="i2" type="checkbox">
                        <label for="i2">Remember me</label>
                        <a class="forgot" href="#">Forgot Password?</a>
                    </div>
                </div>
-->
                <div class="form-group">
                    <a class="sign-up">Register</a>
                </div>

            </div>
        </div>
    </div>

    <script src="assest/js/common.js"></script>
</body>

</html>
