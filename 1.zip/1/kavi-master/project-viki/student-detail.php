<?php include"assest/common/doctype.php" ?>
<?php include"assest/common/all-links.php" ?>

</head>
<script>
 
  </script>

<body>

    <section class="ic-firtst">
        <div class="container">
            <div class="ic-fulldiv">
                <h1 class="ic-h1 text-center">Student Profile</h1>
                <h3 class="ic-h3 text-center">U.G & research department of history</h3>
                <p class="ic-para text-center">islamiah college (autonomous), vaniyambadi 635 751</p>
                <div class="col-lg-9 ic-forms">
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Name</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder="Name" autocomplete="off">
                        </div>                        
                    </div>
					<div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">University Register Number</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder="University Register Number" autocomplete="off">
                        </div>                        
                    </div>
                
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Date Of Birth</label>
                            <input type="text" class="form-control ic-input" id="datepicker" placeholder="Date Of Birth" autocomplete="off">
                        </div>                        
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Year Of Admission</label>
                            <input type="text" class="form-control ic-input" id="yoadmin" placeholder="Year Of Admission" autocomplete="off">
                        </div>                        
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Mobile Number</label>
                            <input type="text" class="form-control ic-input" id="email" placeholder="Mobile Number" autocomplete="off">
                        </div>                        
                    </div><div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Email ID</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder="Email ID" autocomplete="off">
                        </div>                        
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Age</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder="Age" autocomplete="off">
                        </div>                        
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Community</label>
                            <!-- <input type="email" class="form-control ic-input" id="email" placeholder="Community" autocomplete="off"> -->
							<select name="Community" class="form-control ic-input">
							<option value="select">Select</option>
							  <option value="bc">BC</option>
							  <option value="mbc">MBC</option>
							  <option value="sc">SC</option>
							  <option value="st">ST</option>
							  <option value="obc">OBC</option>
							</select>
                        </div>                        
                    </div>
					 <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Religion</label>
                            <!-- <input type="email" class="form-control ic-input" id="email" placeholder="Community" autocomplete="off"> -->
							<select name="Religion" class="form-control ic-input">
							<option value="select">Select</option>
							  <option value="hindu">Hindu</option>
							  <option value="christian">Christian</option>
							  <option value="muslim">Muslim</option>
							  <option value="buddhism">Buddhism</option>
							  <option value="jainism">Jainism</option>
							  <option value="other">Others</option>
							</select>
                        </div>                        
                    </div>
					<div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Blood Group</label>
                            <!-- <input type="email" class="form-control ic-input" id="email" placeholder="Blood Group" autocomplete="off"> -->
							<select name="Blood" class="form-control ic-input">
							<option value="volvo">Select</option>
							  <option value="a+">A+</option>
							  <option value="o+">O+</option>
							  <option value="b+">B+</option>
							  <option value="ab+">AB+</option>
							  <option value="a-">A-</option>
							  <option value="o-">O-</option>
							  <option value="b-">B-</option>
							  <option value="ab-">AB-</option>
							</select>
							
                        </div>                        
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Idetification Marks</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder="Idetification Marks" autocomplete="off">
                        </div>                        
                    </div>
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Extra Curricular Activities</label>
                            <input type="text" class="form-control ic-input" id="email" placeholder="Extra Curricular Activities" autocomplete="off">
                        </div>                        
                    </div>
                    
                    <div class="col-lg-6">
                        <div class="form-group">
                           
                           <div class="father_details">
                               <label for="fatherdetails" class="ic-label">Father Details :-</label>
                           </div>
                            <label for="email" class="ic-label"> Name</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder=" Name" autocomplete="off">
                            
                            <label for="email" class="ic-label"> Occupation</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder=" Occupation" autocomplete="off">
                            
                            <label for="email" class="ic-label"> Qualification</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder=" Qualification" autocomplete="off">
                            
                            <label for="email" class="ic-label"> Mobile No</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder=" Mobile No" autocomplete="off">
                            
                            
                            
                            
                        </div>                        
                    </div>
                    
                    <div class="col-lg-6">
                        <div class="form-group">
                           <div class="mother_details">
                               <label for="motherdetails" class="ic-label">Mother Details :-</label>
                           </div>
                             
                            <label for="email" class="ic-label"> Name</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder=" Name" autocomplete="off">
                            
                            <label for="email" class="ic-label">Occupation</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder=" Occupation" autocomplete="off">
                            
                            <label for="email" class="ic-label"> Qualification</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder=" Qualification" autocomplete="off">
                            
                            <label for="email" class="ic-label"> Mobile No</label>
                            <input type="email" class="form-control ic-input" id="email" placeholder=" Mobile No" autocomplete="off">
                            
                            
                            
                        </div>                        
                    </div>
                    
                    
                    <div class="col-lg-6">
                        <div class="form-group">
                            <label for="email" class="ic-label">Permanet Address</label>
                            <textarea class="form-control" id="permantadd" name="address"  rows="5" cols="10" ></textarea>
                        </div>
                    </div>
                    
                    <div class="col-lg-6">
                        <div class="form-group">
                           <input type="checkbox" name="Comm_add" onclick="bind_data(this.form)">
                           <em>Check if Permant Address is Same as Communication Address</em>
                            <label for="email" class="ic-label">Communication Address</label>
                            <textarea class="form-control" id="commadd" name="addressforcom" rows="5" cols="10" ></textarea>
                        </div>
                    </div>
                    
                    
                </div>
                <div class="col-lg-3 ic-forms pull-right">
                    <div class="ic-img">
                        <input type="file" class="ic-photo">
                        <p class="ic-img-para">Upload Photo</p>
                    </div>
                </div>
            </div>
        </div>
    </section>








    <script src="assest/js/common.js"></script>
</body>

</html>
