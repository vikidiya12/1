<?php include"assest/common/doctype.php" ?>
<?php include"assest/common/all-links.php" ?>
</head>
<body>
   
<!--
   <div id="preloader">
  <div id="status">&nbsp;</div>
</div>
-->
  
  
<section class="ic-firtst">
    <div class="container">
        <div class="ic-fulldiv">
            <h1 class="ic-h1 text-center">Student Profile</h1>
            <h3 class="ic-h3 text-center">U.G & research department of history</h3>
            <p class="ic-para text-center">islamiah college (autonomous), vaniyambadi 635 751</p>
            
            
            <nav class="navbar navbar-expand-sm bg-primary navbar-dark">
                
            </nav>
        </div>
    </div><!-- container -->
      
</section>
   
    
<script src="assest/js/common.js"></script>
</body>
</html>
