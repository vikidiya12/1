 <link rel="stylesheet" href="assest/font/font-style.css">
 <link rel="stylesheet" href="assest/css/bootstrap.css">
  <link rel="stylesheet" href="assest/css/style.css">
  <link rel="stylesheet" href="assest/css/jqueryui.1.12.1.css">
  
  
  <script src="assest/js/jquery.js"></script>
  <script src="assest/js/bootstrap.min.js"></script>
  <script src="assest/js/jquery.1.12.4.js"></script>
  <script src="assest/js/jquery-ui.js"></script>
  
  
  
  
  
<!--  <link href="https://fonts.googleapis.com/css?family=Lora:400,400i,700,700i|Open+Sans:400,400i,600,600i,700,700i" rel="stylesheet">-->